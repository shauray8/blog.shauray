# docSlider.js
docSlider.js is a JavaScript plugin that works without jQuery.  
Change the web sections to a one-page scroll.  
It works on modern browser as Chrome, Firefox, Safari, Edge, IE11.


## Demo & Document
* [Demo Page](https://prjct-samwest.github.io/docSlider/)
* [Document](https://prjct-samwest.github.io/docSlider/document.html)


## License
Created by SamWest.  
Copyright (c) 2020 SamWest.  
This plugin is released under the MIT License.